Project Title:	Extra Credit - Polynomial

Project Description: 
This program is a interactive simulation of a polynomial. By getting input from the user through console, terms from a polynomial are made into objects and inserts into a linear linked list. With the use of linear linked list, the program calculates various calculations such as scaling a polynomial, calculating first three derivatives, subtracting two polynomials, and evaulating a polynomial at a given number. The resulted polynomial has its coefficents and exponents printed in sequence and arranged attractively.


Version or Date: 2.0 - 4/15/16

How to Start the Project: Driver.java

Author:	Chris Banci

User Instructions: Please run the driver file to run the simulation and save/exit using option from menu to save log.