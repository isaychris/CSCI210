Project Title:	Extra Credit - Factorial.

Project Description: This program calculates the given factorial specified by user in console. With the help of objectlist and objectlistNode class, it is possible to implement very large factorials factorial using linear linked lists. Each object in the linear link lists contains 3 digit. To output very large lists, the linked list is traversed and the object containing the digits is printed out.

Version or Date: 2.0 - 4/15/16

How to Start the Project: Driver.java

Author:	Chris Banci

User Instructions: Please run the driver file to run the simulation.