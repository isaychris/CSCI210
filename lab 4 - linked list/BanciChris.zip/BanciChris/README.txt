Project Title:	Lab 4 - Payroll Lab

Project Description: This program simulates a payroll of a list of employees. Using three files (payroll, hirelist, and firelist), we parse the data into employee objects, then add them into linear linked lists by the implementation of ObjectListNode and ObjectList classes. By the manipulation of linear linked lists, we can traverse the list to find all woman on the payroll, find loyal employees, give raise to employees, sort employees by last name, hire new employees, and fire employees. To sort employees, we implement the Comparable interface to compare two objects using the compareTo method.

Version or Date: 2.0 - 4/15/16

How to Start the Project: Driver.java

Author:	Chris Banci

User Instructions: Please run the driver file to run the simulation.