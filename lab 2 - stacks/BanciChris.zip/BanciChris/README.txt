Project Title:	Lab 2 - Stacks

Project Description: This is a program that implements the use of object stacks to convert infix expressions to postfix expressions and then evaluating those post fix expressions. To do this, the program first parses lines of infix expressions from a text file and checks to see if they are valid. Once they pass the validity test, it is then when the infix expression can be converted to postfix. For extra credit, an error message is given when a parenthesis is missing or has extra. Also for extra credit, an error message is given when either operator or operand is adjacent to each other.

Version or Date: 2.0 - 2/25/16

How to Start the Project: Driver.java

Author:	Chris Banci

User Instructions: Compile and run to start the program.